# golf pkg creation ----
usethis::create_package(path = 'C:/Users/Erik/Desktop/Programming/R/Sports/golf', roxygen = TRUE)

# golf pkg build/install ----
devtools::document(pkg = 'C:/Users/Erik/Desktop/Programming/R/Sports/golf')
devtools::build(pkg = 'C:/Users/Erik/Desktop/Programming/R/Sports/golf', path = 'C:/Users/Erik/Desktop/Programming/R/Sports/golf', binary = T, vignettes = F)

# one-time re-set of the internal clock; discrepancy causes note generation in pkg build check
#usethis::edit_r_environ()
# usethis::use_gpl3_license()

devtools::check(pkg = 'C:/Users/Erik/Desktop/Programming/R/Sports/golf', document = T, vignettes = F, cran = T)
devtools::load_all(export_all = T)

devtools::uninstall('C:/Users/Erik/Desktop/Programming/R/Sports/golf',unload = T, quiet = T)

devtools::install('C:/Users/Erik/Desktop/Programming/R/Sports/golf', reload = T, build = T, dependencies = T)
devtools::install('C:/Users/Erik/Desktop/Programming/R/Sports/golf', reload = T, build = F, dependencies = T)


roxygen2::roxygenize(clean = TRUE, package.dir = 'C:/Users/Erik/Desktop/Programming/R/Sports/golf')
# pkgbuild::check_build_tools(debug = TRUE)

# golf pkg use news MD ----
usethis::use_news_md()
# golf pkg github standard check (builds R CMD check workflow)----

library(testthat)
usethis::use_github_action("check-standard")
biocthis::use_bioc_github_action()
install.packages("covr")
library(covr)

usethis::use_news_md()
usethis::use_vignette("golf")
usethis::use_vignette(name = 'predicting_gross_score.Rmd', title = 'Predicting Gross Scores')
usethis::use_vignette(name = 'uploading_new_round.Rmd', title = 'Uploading New Scores')

# golf pkg test that ----
testthat::test_that("golf")
usethis::use_testthat()
usethis::use_test()

# golf pkg data upload ----
library(golf)
library(tidyverse)
library(RSQLite)
db_file <- system.file("extdata", "golf_data.db", package = "golf")

db_file <- dir(path = getwd(), pattern = 'golf_data.db', full.names = T, recursive = T)
con <- DBI::dbConnect(drv = RSQLite::SQLite(), dbname = db_file)
rm(list = ls()[which(grepl(ls(), pattern = 'db_') == T)])
rm(list = ls()[which(grepl(ls(), pattern = 'con') == F)])
DBI::dbDisconnect(conn = con)

RSQLite::dbGetQuery(conn = con, statement = paste0("SELECT DISTINCT * FROM rounds LIMIT 9;"))
  # gather data ----
courses <- c('Silverbell', 'Dell', 'Randolph', 'Randolph', 'Randolph',
             'Randolph', 'Randolph', 'Randolph', 'Dell', 'Dell',
             'Dell', 'Silverbell', 'Randolph', 'Dell', 'Dell',
             'Randolph', 'Randolph', 'Sewailo', 'Arizona National', 'Silverbell',
             'Silverbell')
dates <- c('2025-12-21', '2025-12-14', '2025-12-07', '2025-11-09', '2025-10-26',
           '2025-10-05', '2025-09-21', '2025-07-13', '2025-08-03', '2025-08-31',
           '2025-09-07', '2025-06-01', '2025-05-04', '2025-05-18', '2025-06-08',
           '2025-06-22', '2025-07-20', '2025-07-27', '2025-08-24', '2025-10-19',
           '2025-11-30')
tees <- c('white', 'white', 'white', 'white', 'white',
          'white', 'white', 'white', 'white', 'white',
          'white', 'white', 'white', 'white', 'white',
          'white', 'white', 'white', 'white', 'white',
          'white')
hole_scores <- list(c(5, 6, 3, 5, 5, 3, 6, 5, 3, 5, 6, 2, 5, 6, 3, 4, 4, 7),
                    c(5, 2, 7, 4, 5, 6, 4, 7, 4, 5, 5, 5, 6, 5, 6, 6, 3, 5),
                    c(5, 3, 6, 5, 6, 2, 4, 3, 5, 6, 4, 7, 5, 5, 4, 5, 4, 3),
                    c(6, 4, 6, 5, 5, 3, 5, 4, 7, 3, 4, 3, 4, 4, 5, 4, 5, 4),
                    c(3, 4, 5, 4, 4, 5, 6, 4, 5, 4, 4, 5, 5, 6, 3, 6, 5, 4),
                    c(5, 5, 6, 4, 5, 2, 4, 3, 5, 5, 4, 6, 4, 5, 3, 6, 5, 5),
                    c(5, 6, 5, 5, 5, 3, 6, 4, 7, 6, 5, 4, 6, 5, 4, 5, 5, 4),
                    c(5, 5, 6, 5, 5, 3, 4, 4, 4, 5, 4, 5, 5, 5, 4, 6, 3, 6),
                    c(5, 4, 5, 5, 4, 4, 5, 4, 3, 4, 3, 3, 5, 4, 4, 4, 3, 3),
                    c(4, 4, 5, 4, 4, 5, 6, 6, 3, 5, 4, 5, 4, 6, 5, 7, 4, 4),
                    c(6, 4, 5, 5, 3, 6, 5, 4, 4, 5, 4, 4, 6, 5, 4, 5, 3, 5),
                    c(6, 6, 4, 5, 6, 3, 5, 5, 6, 4, 6, 4, 5, 5, 5, 5, 6, 7),
                    c(6, 5, 5, 5, 7, 4, 6, 4, 6, 5, 3, 4, 6, 5, 3, 5, 5, 4),
                    c(6, 5, 5, 5, 4, 7, 5, 6, 3, 5, 3, 5, 5, 6, 5, 6, 3, 6),
                    c(6, 3, 6, 5, 4, 7, 4, 4, 3, 5, 2, 5, 7, 6, 5, 4, 7, 5),
                    c(5, 4, 5, 4, 4, 4, 5, 4, 7, 5, 4, 4, 5, 5, 5, 7, 5, 5),
                    c(5, 7, 4, 4, 5, 6, 6, 5, 4, 5, 4, 5, 4, 4, 5, 4, 6, 6),
                    c(6, 4, 3, 7, 4, 7, 4, 5, 4, 5, 5, 4, 4, 5, 4, 6, 7, 4),
                    c(5, 5, 4, 3, 8, 3, 6, 6, 4, 5, 7, 4, 6, 5, 4, 5, 4, 5),
                    c(4, 6, 4, 6, 4, 3, 5, 5, 3, 5, 4, 3, 5, 5, 4, 4, 6, 6),
                    c(5, 6, 3, 5, 4, 2, 5, 5, 3, 4, 5, 4, 4, 5, 4, 5, 4, 8)
)
FIRs <- list(
  c(1, 1, 0, 1, 1, 0, 0, 1, 0,
    0, 1, 0, 1, 0, 1, 0, 0, 0),
  c(0, 0, 0, 0, 0, 1, 1, 1, 0,
    0, 0, 1, 1, 0, 0, 0, 0, 0),
  c(0, 1, 1, 1, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 1),
  c(1, 0, 0, 1, 0, 0, 1, 0, 0,
    1, 0, 0, 1, 1, 0, 1, 0, 1),
  c(0, 0, 1, 0, 0, 0, 1, 0, 0,
    1, 0, 0, 1, 0, 0, 0, 0, 1),
  c(1, 1, 0, 1, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 0),
  c(0, 0, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0),
  c(1, 1, 0, 1, 0, 0, 1, 0, 1,
    1, 0, 1, 1, 0, 0, 0, 1, 1),
  c(1, 0, 0, 0, 0, 1, 0, 1, 0,
    1, 0, 0, 0, 0, 1, 0, 0, 0),
  c(0, 0, 1, 1, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1),
  c(1, 0, 0, 1, 0, 0, 0, 1, 0,
    1, 0, 1, 1, 1, 1, 0, 0, 0),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18))
)
GIRs <- list(
  c(0, 0, 1, 0, 1, 1, 0, 1, 1,
    0, 0, 1, 0, 0, 0, 0, 1, 0),
  c(0,1,0,1,0,0,1,0,0,
    0,0,1,0,0,0,0,0,0),
  c(0,1,1,1,0,1,1,1,0,
    0,0,0,1,0,0,0,1,1),
  c(1, 0, 0, 0, 0, 1, 0, 0, 0,
    1, 0, 1, 1, 1, 0, 1, 0, 1),
  c(1, 0, 0, 0, 0, 0, 0, 0, 1,
    1, 0, 0, 1, 0, 0, 0, 0, 0),
  c(0, 0, 0, 1, 0, 1, 0, 0, 0,
    0, 0, 0, 1, 0, 1, 1, 0, 0),
  c(0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 1),
  c(0, 0, 0, 0, 0, 0, 1 ,0, 1,
    0, 0, 0, 0, 0, 0, 0, 1, 0),
  c(0, 0, 1, 1, 0, 1, 0, 1, 0,
    1, 0, 1, 0, 1, 0, 1, 1, 1),
  c(0, 0, 1, 1, 0, 0, 0, 0, 0,
    1, 0, 0, 1, 0, 0, 0, 0, 1),
  c(0, 1, 1, 0, 1, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 1, 0),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18))
)
putts_rec <- list(
  c(2, 2, 2, 1, 3, 2, 2, 3, 2,
    2, 2, 1, 2, 2, 0, 1, 2, 3),
  c(2, 1, 3, 2, 2, 1, 2, 3, 2,
    2, 2, 3, 2, 2, 2, 2, 1, 2),
  c(1, 1, 3, 3, 2, 1, 2, 2, 1,
    2, 2, 2, 2, 2, 2, 1, 2, 1),
  c(4, 1, 1, 2, 1, 2, 2, 2, 2,
    1, 2, 1, 1, 2, 2, 2, 2, 2),
  c(1, 1, 1, 1, 1, 1, 2, 2, 2,
    2, 1, 2, 2, 2, 1, 2, 2, 1),
  c(1, 2, 1, 2, 2, 1, 1, 1, 1,
    2, 2, 2, 1, 2, 2, 3, 2, 2),
  c(1, 2, 1, 2, 2, 1, 2, 2, 2,
    2, 3, 1, 2, 2, 2, 2, 2, 2),
  c(1, 2, 1, 2, 2, 1, 2, 1, 1,
    1, 2, 2, 1, 2, 2, 2, 1, 2),
  c(2, 2, 2, 3, 2, 2, 2, 2, 1,
    2, 1, 1, 1, 2, 1, 2, 2, 1),
  c(1, 2, 3, 2, 2, 1, 3, 1, 1,
    3, 1, 2, 2, 2, 2, 2, 2, 2),
  c(3, 3, 2, 2, 2, 2, 2, 1, 2,
    2, 2, 2, 2, 2, 1, 2, 2, 2),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18))
)
chips_rec <- list(
  c(1, 0, 0, 1, 0, 0, 1, 0, 0,
    1, 2, 0, 1, 0, 1, 1, 0, 1),
  c(1, 0, 0, 0, 2, 2, 0, 2, 1,
    1, 1, 0, 1, 1, 1, 0, 0, 1),
  c(2, 0, 0, 0, 2, 0, 0, 0, 2,
    0, 1, 1, 0, 1, 1, 1, 0, 0),
  c(0, 1, 1, 1, 1, 0, 0, 1, 2,
    0, 1, 0, 0, 0, 1, 0, 0, 0),
  c(0, 1, 1, 1, 1, 1, 2, 1, 1,
    0, 2, 0, 0, 1, 1, 1, 1, 1),
  c(2, 1, 2, 0, 0, 0, 1, 0, 0,
    1, 1, 0, 0, 0, 0, 0, 1, 1),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(1, 1, 1, 0, 1, 0, 1, 0, 1, 
    0, 1, 0, 1, 0, 1, 0, 0, 0),
  c(1, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 2, 1, 0, 0, 0, 0, 0, 0),
  c(1, 0, 0, 1, 0, 0, 1, 0, 1,
    1, 1, 0, 2, 1, 1, 1, 0, 0),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18))
)
penalties_rec <- list(
  c(rep(0, 18)),
  c(rep(0, 18)),
  c(rep(0, 18)),
  c(0, 0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0),
  c(rep(0, 18)),
  c(rep(0, 18)),
  c(rep(0, 18)),
  c(rep(0, 18)),
  c(rep(0, 18)),
  c(rep(0, 18)),
  c(rep(0, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(NA_real_, 18)),
  c(rep(0, 17), 1)
)
tee_clubs <- list(
  c('D', 'D', 'GW', 'D', 'D', '8', 'D', 'D', '8',
    'D', '4', '8', 'D', 'D', 'D', '4', '4', 'D'),
  c('4', '8', 'D', '3W', 'GW', 'D', 'D', '4', '8',
    'D', '8', 'D', 'D', 'D', 'D', '4', 'GW', 'D'),
  c('4', '4', 'D', 'D', 'D', 'GW', '4', '7', 'D',
    'D', '7', 'D', 'D', 'D', '8', 'D', 'D', 'D'),
  c('4', '4', 'D', 'D', 'D', 'GW', '4', '7', 'D',
    'D', '7', 'D', 'D', 'D', '7', 'D', 'D', 'D'),
  c('4', '4', 'D', 'D', 'D', 'GW', '4', '7', 'D',
    'D', '7', 'D', 'D', 'D', '7', 'D', 'D', 'D'),
  c('4', '4', 'D', 'D', 'D', 'GW', '4', '7', 'D',
    'D', '7', 'D', 'D', 'D', '7', 'D', 'D', 'D'),
  c('4', '4', 'D', 'D', 'D', 'GW', '4', '7', 'D',
    'D', '7', 'D', 'D', 'D', '7', 'D', 'D', 'D'), 
  c(rep('NA', 18)),
  c('4', '7', 'D', 'D', 'GW', 'D', 'D', 'D', '7',
    '4', '7', 'D', 'D', 'D', 'D', '4', 'GW', 'D'),
  c('4', '7', 'D', 'D', 'GW', 'D', 'D', 'D', '7',
    '4', '7', 'D', 'D', 'D', 'D', '4', 'GW', 'D'),
  c('4', '7', 'D', 'D', 'GW', 'D', 'D', 'D', '7',
    '4', '7', 'D', 'D', 'D', 'D', '4', 'GW', 'D'),
  c(rep('NA', 18)),
  c(rep('NA', 18)),
  c(rep('NA', 18)),
  c(rep('NA', 18)),
  c(rep('NA', 18)),
  c(rep('NA', 18)),
  c(rep('NA', 18)),
  c(rep('NA', 18)),
  c(rep('NA', 18)),
  c('4', 'D', 'GW', 'D', 'D', '7', 'D', '4', '7',
    'D', '4', '7', 'D', 'D', 'D', '4', '4', 'D')
)
indeces <- c(10.4, 10.4, 10.9, 11.8, 11.7,
             12.4, 12.4, 13.3, 14.0, 11.9,
             11.9, 11.8, 11.3, 11.3, 12.1, 
             12.9, 13.6, 14.0, 11.9, 11.9,
             11.3)
# gather data from db ----
club_metrics <- RSQLite::dbGetQuery(conn = con, statement = paste0("SELECT DISTINCT * FROM club_metrics;")) |> dplyr::mutate(date = lubridate::as_date(date))

courses <- DBI::dbGetQuery(conn = con, statement = paste0("SELECT DISTINCT course_name, date FROM rounds;")) |> dplyr::select(course_name) |> unlist() |> as.character()
dates <- RSQLite::dbGetQuery(conn = con, statement = paste0("SELECT DISTINCT date FROM rounds;")) |> dplyr::mutate(date = lubridate::as_date(date)) |> unlist() |> as.character() |> as.POSIXlt.Date(tz = 'MST') %>% lubridate::as_date(.)
tees <- RSQLite::dbGetQuery(conn = con, statement = paste0("SELECT DISTINCT course_name, date, tees FROM rounds;")) |> dplyr::select(tees) |> unlist() |> as.character()

hole_scores <- RSQLite::dbGetQuery(conn = con, statement = paste0("SELECT course_name, date, tees, gross FROM rounds;")) |> dplyr::select(date, gross) |> dplyr::mutate(date = lubridate::as_date(date), date = as.character(date)) |> tidyr::chop(cols = gross) |> as.list()
hole_scores <- hole_scores$gross
indeces <- RSQLite::dbGetQuery(conn = con, statement = paste0("SELECT DISTINCT course_name, date, handicap_index FROM rounds;")) |> dplyr::select(handicap_index) |> unlist() |> as.numeric()
FIRs <- RSQLite::dbGetQuery(conn = con, statement = paste0("SELECT course_name, date, FIR FROM rounds;")) |> dplyr::select(date, FIR) |> dplyr::mutate(date = lubridate::as_date(date), date = as.character(date)) |> tidyr::chop(cols = FIR) |> as.list()
FIRs <- FIRs$FIR
GIRs <- RSQLite::dbGetQuery(conn = con, statement = paste0("SELECT course_name, date, GIR FROM rounds;")) |> dplyr::select(date, GIR) |> dplyr::mutate(date = lubridate::as_date(date), date = as.character(date)) |> tidyr::chop(cols = GIR) |> as.list()
GIRs <- GIRs$GIR
putts_rec <- RSQLite::dbGetQuery(conn = con, statement = paste0("SELECT course_name, date, putts FROM rounds;")) |> dplyr::select(date, putts) |> dplyr::mutate(date = lubridate::as_date(date), date = as.character(date)) |> tidyr::chop(cols = putts) |> as.list()
putts_rec <- putts_rec$putts
chips_rec <- RSQLite::dbGetQuery(conn = con, statement = paste0("SELECT course_name, date, chips FROM rounds;")) |> dplyr::select(date, chips) |> dplyr::mutate(date = lubridate::as_date(date), date = as.character(date)) |> tidyr::chop(cols = chips) |> as.list()
chips_rec <- chips_rec$chips
penalties_rec <- RSQLite::dbGetQuery(conn = con, statement = paste0("SELECT course_name, date, penalties FROM rounds;")) |> dplyr::select(date, penalties) |> dplyr::mutate(date = lubridate::as_date(date), date = as.character(date)) |> tidyr::chop(cols = penalties) |> as.list()
penalties_rec <- penalties_rec$penalties
tee_clubs <- RSQLite::dbGetQuery(conn = con, statement = paste0("SELECT course_name, date, tee_club FROM rounds;")) |> dplyr::select(date, tee_club) |> dplyr::mutate(date = lubridate::as_date(date), date = as.character(date)) |> tidyr::chop(cols = tee_club) |> as.list()
tee_clubs <- tee_clubs$tee_club
# club_metrics <- RSQLite::dbGetQuery(conn = con, statement = paste0("SELECT DISTINCT * FROM club_metrics")) |> dplyr::mutate(date = lubridate::as_date(date))
  # apply functions ----
Card <- list()
for (i in seq_along(1:26) ){
  Card[[i]] <- golf::getCourse(course = courses[i], date = dates[i], tees = tees[i])
  Card[[i]] <- golf::logScore(Scorecard = Card[[i]], hole_by_hole = hole_scores[[i]], GHIN = '10526424', index = indeces[i], FIR = FIRs[[i]], GIR = GIRs[[i]], putts = putts_rec[[i]], chips_rec[[i]], penalties = penalties_rec[[i]], tee_club = tee_clubs[[i]])
}
Card <- purrr::list_merge(Card) %>%
  purrr::map_df(., .f = as.data.frame) |> 
  dplyr::mutate(date = lubridate::as_date(date)) |> 
  dplyr::full_join(club_metrics |> dplyr::rename(course = course_name)) |> 
  dplyr::distinct()



# golf pkg data setup ----
usethis::use_data_raw('Card')
# golf pkg data load ----
usethis::use_data(Card, overwrite = T)

# check and release golf pkg ----
#sign in
rhub::validate_email()
# check
devtools::check_rhub()

devtools::check_win_devel()

cran_checks <- rhub::check_for_cran()

#check package viability on all OSs
devtools::check_win_devel()

results$cran_summary()

devtools::test_coverage()

#release to cran
devtools::release()
devtools::spell_check(pkg = 'C:/Users/Erik/Desktop/Programming/R/Sports/golf', vignettes = TRUE, use_wordlist = TRUE)


##
gitcreds::gitcreds_set(url = 'https://www.github.com/eriklarsen4/golf')
rhub::rhub_check(gh_url = 'https://www.github.com/eriklarsen4/golf')
usethis::create_github_token()

usethis::use_spell_check(vignettes = TRUE, lang = 'en-US', error = FALSE)

# misc ----


# ----
spelling::update_wordlist()