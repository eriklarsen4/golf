library(rvest)
library(purrr)

rvest::read_html('https://datagolf.com/stats/tour-lists') |> 
  rvest::html_nodes(xpath = '//*[@id="body-wrapper"]/div[1]/div[2]/div[8]') |> 
  rvest::html_nodes('div') |> 
  rvest::html_table()
  rvest::html_nodes(css = '#body-wrapper > div.wrapper > div.container-fluid > div.table-div') |> 
  rvest::html_node('datahead lists-col player-col')
  rvest::html_table()
  rvest::html_name()
  rvest::html_text(trim = T)
  rvest::html_elements()
  rvest::html_nodes(xpath = '//*[@id="body-wrapper"]/div[1]/div[2]/div[8]') |> 
  rvest::html_table()
  rvest::html_elements(xpath = '//*[@id="body-wrapper"]/div[1]/div[2]/div[8]')
  rvest::html_nodes('//*[@id="__next"]/div[3]/div/div[1]/main/div/div[7]')
  rvest::html_element('tbody')
  rvest::html_nodes('#__next > div.css-1hs4aw1 > div > div.css-i5hv4r > main > div > div:nth-child(9) > div.css-0 > div > div > div > div.simplebar-wrapper > div.simplebar-mask > div > div > div') |> 
  unlist()
  rvest::html_element(css = '#__next > div.css-1hs4aw1 > div > div.css-i5hv4r > main > div > div:nth-child(9) > div.css-0 > div > div > div > div.simplebar-wrapper > div.simplebar-mask > div > div > div')
  rvest::html_element(css = '#__next > div.css-1hs4aw1 > div > div.css-i5hv4r > main > div > div:nth-child(9) > div.css-0 > div > div > div > div.simplebar-wrapper > div.simplebar-mask > div > div > div > table')
  rvest::html_node(xpath = '/html/body/div[1]/div[3]/div/div[1]/main/div/div[7]/div[2]/div/div/div/div[1]/div[2]/div/div/div/table')
  rvest::html_element(xpath = '/html/body/div[1]/div[3]/div/div[1]/main/div/div[7]/div[2]/div/div/div/div[1]/div[2]/div/div/div/table')
  rvest::html_element(css = '#__next > div.css-1hs4aw1 > div > div.css-i5hv4r > main > div > div:nth-child(9) > div.css-0 > div > div > div > div.simplebar-wrapper > div.simplebar-mask > div > div > div > table')
  
  rvest::read_html('https://www.espn.com/golf/stats/player/_/table/general') |> 
    rvest::html_nodes(xpath = '/html/body/div[1]/div/div/div/div/main/div[2]/div[2]/div/div') |> 
    rvest::html_elements('table') |> 
    rvest::html_table() |> 
    purrr::list_merge()
  