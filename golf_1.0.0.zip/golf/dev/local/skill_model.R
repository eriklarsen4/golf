library(KFAS)

# State equation: skill_t = skill_{t-1} + noise
mod <- SSModel(
  y ~ SSMtrend(1, Q = list(skill_var)) +
    X + 
    SSMregression(~ course, Q = course_var),
  H = meas_var
)

fit <- fitSSM(mod, inits)
out <- KFS(fit$model)
skill_est <- out$alphahat[, 1]